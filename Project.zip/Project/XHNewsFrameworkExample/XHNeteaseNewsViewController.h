//
//  XHNeteaseNewsViewController.h
//  XHNewsFrameworkExample
//
//  Created by 曾 宪华 on 14-1-24.
//  Copyright (c) 2014年 曾宪华 开发团队(http://iyilunba.com ) 本人QQ:543413507 本人QQ群（142557668）. All rights reserved.
//

// 当编译的时候，如果出现报错，提示头文件找不到的时候，把XHNewsFramework.framework拖出工程，然后再拖进来，这样就不会报错了，因为github上传后所引起的，具体操作可以看fixTheHeadError.gif文件，会教你怎么做。
#import <XHNewsFramework/XHNewsContainerViewController.h>

@interface XHNeteaseNewsViewController : XHNewsContainerViewController
@end
